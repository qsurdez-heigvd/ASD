#ifndef LISTE_H
#define LISTE_H

#include "LSIterator.h"
#include <utility> // std::swap;
#include <forward_list>
#include <cassert>

template<typename T>
class ListeSimple {
public:
   using value_type = T;
   using reference = T &;
   using const_reference = T const &;

private:
   struct Maillon {
      value_type valeur;
      Maillon *suivant;
   };

   Maillon avant_premier;

public:
   using iterator = LSIterator<value_type>;
   friend iterator;

   using const_iterator = LSConstIterator<value_type>;
   friend const_iterator;

   const_iterator cbegin() const noexcept {
      return const_iterator(avant_premier.suivant);
   }

   iterator begin() noexcept { return iterator(avant_premier.suivant); }

   const_iterator begin() const noexcept { return cbegin(); }

   ListeSimple() : avant_premier{value_type{}, nullptr} {}

   ~ListeSimple() {
      /*Maillon *maillon = avant_premier.suivant;
      Maillon *tmp;
      while (maillon != nullptr) {
         tmp = maillon;
         maillon = maillon->suivant;
         delete tmp;
      }*/
      while (!empty()) {
         pop_front();
      }
   }

   ListeSimple(const ListeSimple<T>& autre) : avant_premier{T{}, nullptr} {
      if (this == &autre) return;

      iterator iterateur_courant = before_begin();
      for (const_iterator i = autre.cbegin(); i != autre.cend(); i++) {
         insert_after(iterateur_courant, *i);
         iterateur_courant++;
      }
   }

   ListeSimple &operator=(const ListeSimple<T> &autre) {
      if (this == &autre) {
         return *this;
      }
      /*avant_premier.valeur = autre.avant_premier.valeur;
      *avant_premier.suivant = *autre.avant_premier.suivant;*/
      auto tmp(autre);
      swap(tmp);
      return *this;

   }

   // A compléter pour fournir ...
   //
   // end, cend, before_begin, cbefore_begin, empty, front
   // insert_after, erase_after, splice_after, push_front, pop_front,
   // swap, sort, ainsi que constructeur, opérateur d'affectation et destructeur

   const_iterator cend() const noexcept {
      return const_iterator(nullptr);
   }

   const_iterator end() const noexcept { return cend(); }

   iterator end() noexcept {
      /*iterator fin = this->begin();
      while (fin != nullptr) {
         fin = fin.m->suivant;
      }
      return fin;*/
      return iterator(nullptr);
   }

   iterator before_begin() noexcept {
      return iterator(&avant_premier);
   }

   const_iterator before_begin() const noexcept {
      return cbefore_begin();
   }

   const_iterator cbefore_begin() const noexcept {
      return const_iterator(&avant_premier);
   }

   [[nodiscard]] bool empty() const noexcept {
      return begin() == nullptr;
   }

   reference front() {
      if (empty()) throw std::length_error(__func__);

      return *begin();
   }

   const_reference front() const noexcept {
      if (empty()) throw std::length_error(__func__);

      return *begin();
   }

   /*iterator insert_after(iterator pos, const_reference value) {
      auto nouveau_maillon = new Maillon{value, pos.m->suivant};
      if (nouveau_maillon == nullptr) {
         throw std::bad_alloc();
      }
      pos.m->suivant = nouveau_maillon;
      return next(pos);
   }*/

   void insert_after(iterator pos, const T& value) const {
      if (pos == nullptr) throw std::out_of_range(__func__);
      auto nouveau_maillon = new Maillon{value, pos.m->suivant};
      if (nouveau_maillon == nullptr) {
         throw std::bad_alloc();
      }
      pos.m->suivant = nouveau_maillon;
   }

   iterator erase_after(iterator position) {
      if (position.m->suivant == nullptr)
         throw std::out_of_range(__func__);
      if (position == nullptr)
         throw std::out_of_range(__func__);
      auto tmp = position.m->suivant;
      position.m->suivant = tmp->suivant;
      delete (tmp);
   }

   void splice_after(iterator pos, iterator first, iterator last) {
      if (pos == first or pos == last or first == last) {
         return;
      }
      /*
      if (pos.m->suivant != nullptr) {
         last.m->suivant = pos.m->suivant;
      }
      pos.m->suivant = first.m;
      */
      Maillon* tmp = pos.m->suivant;
      pos.m->suivant = first.m->suivant;
      first.m->suivant = last.m->suivant;
      last.m->suivant = tmp;
   }

   void push_front(const_reference value) {
      insert_after(before_begin(), value);
   }

   void pop_front() {
      if (avant_premier.suivant == nullptr) {
         throw std::out_of_range(__func__);
      }
      erase_after(before_begin());
   }

   void swap(ListeSimple<value_type> &other) noexcept {
      if (before_begin() == other.before_begin()) return;

      using std::swap;
      swap(avant_premier, other.avant_premier);
   }


   void sort(){
      if(empty()) return;

      iterator j = before_begin();

      auto iMin = j;
      auto i = j;
      while (next(j) != end()) {
         iMin = j;
         i = next(j);
         while (next(i) != end()) {
            if (*next(i) < *next(iMin)) {
               iMin = i;
            }
            ++i;
         }
         if (iMin != j) {
            splice_after(j, iMin, next(iMin));
         }
         ++j;
      }
   }

   /*void fusionSort() {

      auto avant = before_begin();
      auto i = begin();
      auto iMin = begin();

      while (avant != end()) {
         i = next(avant);
         iMin = i;
         while (i != end()) {
            if (*i < *iMin)
               iMin = i;
            ++i;
         }
         splice_after(avant, iMin, next(iMin));
         ++avant();
      }
   }
    */
};

#endif //LISTE_H

